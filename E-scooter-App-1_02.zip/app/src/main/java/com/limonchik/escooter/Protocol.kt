package com.limonchik.escooter

/**
 * Чистый Kotlin, без Android. Источник: дизассемблирование classes.dex из KCQ Scooter 1.5.4
 * (RequestPackage, DeviceMgr, Utils, SettingInfo, SettingInfo2, App.onNotifyData).
 */
object Protocol {
    const val SIG_A5 = 0xA5
    const val SIG_A7 = 0xA7
    const val SIG_A8 = 0xA8

    // Номера бит байта записи b1 (индекс символа в SettingInfo.toString(), символ i = бит i).
    const val W_GEAR_INV = 0
    const val W_CRUISE = 1
    const val W_START = 2
    const val W_HEAD = 3
    const val W_TAIL = 4
    const val W_UNIT = 5
    const val W_LOCK = 6
    const val W_OFF = 7

    private fun u(f: ByteArray, i: Int): Int = f[i].toInt() and 0xFF
    fun bit(v: Int, i: Int): Boolean = ((v shr i) and 1) == 1

    /**
     * Кадр записи: AA CC SIG b1 b2 (b1^SIG) ((b1+SIG+(b1^SIG)) & FF) EE.
     * Как RequestPackage: байт b2 в обе контрольные суммы НЕ входит.
     */
    fun frame(sig: Int, b1: Int, b2: Int): ByteArray {
        val d1 = b1 and 0xFF
        val x = (d1 xor sig) and 0xFF
        val sum = (d1 + sig + x) and 0xFF
        return intArrayOf(0xAA, 0xCC, sig, d1, b2 and 0xFF, x, sum, 0xEE)
            .map { it.toByte() }.toByteArray()
    }

    fun hex(b: ByteArray): String = b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    // ---------- разбор уведомлений FFF7 ----------

    data class Setting(
        val gear: Int,
        val gearFlag: Boolean,
        val cruise: Boolean,
        val startMode: Boolean,
        val headlight: Boolean,
        val taillight: Boolean,
        val unitMiles: Boolean,
        val lock: Boolean,
    ) {
        /** SettingInfo.toString() -> байт записи (символ i = бит i, символ 7 всегда 0). */
        fun writeByte(): Int {
            var v = 0
            if (!gearFlag) v = v or (1 shl W_GEAR_INV)
            if (cruise) v = v or (1 shl W_CRUISE)
            if (startMode) v = v or (1 shl W_START)
            if (headlight) v = v or (1 shl W_HEAD)
            if (taillight) v = v or (1 shl W_TAIL)
            if (unitMiles) v = v or (1 shl W_UNIT)
            if (lock) v = v or (1 shl W_LOCK)
            return v
        }
    }

    /** Байт 11 кадра AA 55: биты 0-1 передача, 2 круиз, 3 старт, 4 передний, 5 задний, 6 единицы, 7 блокировка. */
    fun parseSetting(b: Int): Setting {
        // Utils.getGear: "11" -> 3, "10" -> 1, "01" -> 2, иначе 1 (строка = биты 0 и 1 по порядку)
        val gear = when {
            bit(b, 0) && bit(b, 1) -> 3
            bit(b, 0) -> 1
            bit(b, 1) -> 2
            else -> 1
        }
        return Setting(
            gear = gear,
            gearFlag = if (gear == 3) false else bit(b, 0),
            cruise = bit(b, 2),
            startMode = bit(b, 3),
            headlight = bit(b, 4),
            taillight = bit(b, 5),
            unitMiles = bit(b, 6),
            lock = bit(b, 7),
        )
    }

    data class Fault(val title: String, val hint: String)

    data class Status(
        val speedRaw: Int,
        val totalRaw: Int,
        val tripRaw: Int,
        val battery: Int,
        val fault1: Int,
        val flags2: Int,
        val settingByte: Int,
        val rideSeconds: Int,
    ) {
        /** Оригинал: getUnitData(speed, 1, 10, miles) = raw / 10 (км/ч), в милях ещё / 1.609344. */
        val speedKmh: Double get() = speedRaw / 10.0
        val totalKm: Double get() = totalRaw / 10.0
        val tripKm: Double get() = tripRaw / 10.0
        val setting: Setting get() = parseSetting(settingByte)
        val cycling: Boolean get() = bit(flags2, 3)
        val thirdGearView: Boolean get() = bit(flags2, 5)
        val faults: List<Fault>
            get() = buildList {
                if (bit(fault1, 0)) add(Fault("Датчик Холла", "Вероятно, датчик положения в моторе или его разъём"))
                if (bit(fault1, 1)) add(Fault("Силовые ключи (MOS)", "Вероятно, неисправность силовой части контроллера"))
                if (bit(fault1, 2)) add(Fault("Тормоз", "Вероятно, датчик тормоза или его проводка"))
                if (bit(fault1, 3)) add(Fault("Ручка газа", "Вероятно, ручка газа или её проводка"))
                if (bit(fault1, 4)) add(Fault("Пониженное напряжение", "Батарея разряжена или просела"))
                if (bit(fault1, 5)) add(Fault("Ошибка связи", "Нет обмена данными между узлами самоката"))
                if (bit(fault1, 6)) add(Fault("Повышенное напряжение", "Напряжение выше допустимого"))
                if (bit(fault1, 7)) add(Fault("Ошибка нуля", "Флаг zero из кадра контроллера"))
                if (bit(flags2, 0)) add(Fault("Блокировка ротора", "Флаг block из кадра контроллера"))
                if (bit(flags2, 6)) add(Fault("Температура", "Перегрев или флаг температуры контроллера"))
            }
    }

    /** AA 55: скорость LE (b2,b3), пробег b4-5 и b6-7 (0.1 км), батарея b8, ошибки b9/b10, настройки b11, время b12-13. */
    fun parseStatus(f: ByteArray): Status? {
        if (f.size < 14 || u(f, 0) != 0xAA || u(f, 1) != 0x55) return null
        return Status(
            speedRaw = (u(f, 3) shl 8) or u(f, 2),
            totalRaw = u(f, 4) or (u(f, 5) shl 8),
            tripRaw = u(f, 6) or (u(f, 7) shl 8),
            battery = u(f, 8),
            fault1 = u(f, 9),
            flags2 = u(f, 10),
            settingByte = u(f, 11),
            rideSeconds = u(f, 12) or (u(f, 13) shl 8),
        )
    }

    /** AA 56: b2 биты 0-2 (pedView, bit1, pedBit2), скорости передач b5,b6,b7 и стартовая b8. */
    data class Ped(val view: Boolean, val bit1: Boolean, val bit2: Boolean, val one: Int, val two: Int, val three: Int, val start: Int)

    fun parsePed(f: ByteArray): Ped? {
        if (f.size < 9 || u(f, 0) != 0xAA || u(f, 1) != 0x56) return null
        val b = u(f, 2)
        return Ped(bit(b, 0), bit(b, 1), bit(b, 2), u(f, 5), u(f, 6), u(f, 7), u(f, 8))
    }

    /** AA 57: допустимые пределы скорости контроллера: b8/b9 (1-я), b10/b11 (2-я), b12/b13 (3-я). */
    data class Bounds(val min1: Int, val max1: Int, val min2: Int, val max2: Int, val min3: Int, val max3: Int) {
        fun range(gear: Int): Pair<Int, Int> = when (gear) {
            1 -> min1 to max1
            2 -> min2 to max2
            else -> min3 to max3
        }
    }

    fun parseBounds(f: ByteArray): Bounds? {
        if (f.size < 14 || u(f, 0) != 0xAA || u(f, 1) != 0x57) return null
        return Bounds(u(f, 8), u(f, 9), u(f, 10), u(f, 11), u(f, 12), u(f, 13))
    }

    // ---------- команды записи (FFF6) ----------

    /** Данные для записи, собранные из последних уведомлений. */
    data class Snap(val setting: Setting, val thirdGearView: Boolean, val pedView: Boolean, val pedBit2: Boolean)

    // Байт b2 (SettingInfo2.toString -> Utils.bitToByte БЕЗ разворота строки, первый символ = старший бит):
    // "0", ped, pedView, "0", thirdGearView, thirdGear, disconnect, recover
    const val B2_PED = 0x40
    const val B2_PED_VIEW = 0x20
    const val B2_THIRD_VIEW = 0x08
    const val B2_THIRD = 0x04
    const val B2_DISCONNECT = 0x02
    const val B2_RECOVER = 0x01

    /** Второй байт A5-кадра как в RequestPackage.getData: gear==0 -> пешеходный, gear==3 -> третья передача. */
    fun byte2(gear: Int, thirdGearView: Boolean): Int =
        (if (gear == 0) B2_PED else 0) or (if (thirdGearView) B2_THIRD_VIEW else 0) or (if (gear == 3) B2_THIRD else 0)

    /** Логика DeviceMgr.write(): в «пешеходном виде» передача подменяется. */
    fun effectiveGear(g: Int, pedView: Boolean, pedBit2: Boolean): Int {
        var gear = g
        if (pedView) {
            if (pedBit2) gear = 0 else if (gear != 3) gear = 1
        }
        return gear
    }

    /** A5-кадр: взять байт состояния, установить бит [bit] в [on] (DeviceMgr.write(i, i+1, flag)). */
    fun bitCommand(s: Snap, bit: Int, on: Boolean, gearOverride: Int? = null): ByteArray {
        val mask = 1 shl bit
        val cur = s.setting.writeByte()
        val b1 = if (on) cur or mask else cur and mask.inv()
        val gear = effectiveGear(gearOverride ?: s.setting.gear, s.pedView, s.pedBit2)
        return frame(SIG_A5, b1, byte2(gear, s.thirdGearView))
    }

    fun gear1(s: Snap): ByteArray = bitCommand(s, W_GEAR_INV, false, 1)
    fun gear2(s: Snap): ByteArray = bitCommand(s, W_GEAR_INV, true, 2)

    /** DeviceMgr.setThireGear -> RequestPackage.getThirdGearData. */
    fun gear3(s: Snap): ByteArray =
        frame(SIG_A5, s.setting.writeByte() or 1, (if (s.thirdGearView) B2_THIRD_VIEW else 0) or B2_THIRD)

    /** DeviceMgr.closeDevice(flag) -> write(7, 8, flag): бит 7 байта b1. В оригинале строка лога «关机» (выключение). */
    fun shutdown(s: Snap): ByteArray = bitCommand(s, W_OFF, true)

    /** RequestPackage.pedestrian: b1 = текущее состояние без изменений, b2: 0x40 = пешеходный, 0x20 = pedView. */
    fun pedestrian(s: Snap, on: Boolean): ByteArray =
        frame(SIG_A5, s.setting.writeByte(), (if (on) B2_PED else 0) or (if (s.pedView) B2_PED_VIEW else 0))

    /** RequestPackage.getRestoreData («恢复出厂设置»): b2 = recover (0x01) + thirdGearView/thirdGear. */
    fun restore(s: Snap): ByteArray =
        frame(
            SIG_A5,
            s.setting.writeByte(),
            (if (s.thirdGearView) B2_THIRD_VIEW else 0) or (if (s.setting.gear == 3) B2_THIRD else 0) or B2_RECOVER,
        )

    /** A7: скорость 1-й и 2-й передачи, км/ч. */
    fun speed12(g1: Int, g2: Int): ByteArray = frame(SIG_A7, g1, g2)

    /** A8: скорость 3-й передачи и стартовая (как SpeedSettingActivity$3). */
    fun speed3(g3: Int, start: Int, curThree: Int): ByteArray =
        frame(SIG_A8, g3, if (start != 0) start else if (g3 >= curThree) 8 else curThree)
}
