package com.limonchik.escooter

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Два дизайна: мягкий «Apple» и графитовый «Ninebot» с оранжевым акцентом. */
enum class DesignStyle { APPLE, NINEBOT }

data class Palette(
    val bg: Color,
    val card: Color,
    val cardAlt: Color,
    val text: Color,
    val sub: Color,
    val accent: Color,
    val onAccent: Color,
    val good: Color,
    val warn: Color,
    val bad: Color,
    val divider: Color,
    val radius: Dp,
    val tileRadius: Dp,
    val dark: Boolean,
)

fun paletteFor(style: DesignStyle, dark: Boolean): Palette = when (style) {
    DesignStyle.APPLE ->
        if (dark) {
            Palette(
                bg = Color(0xFF000000), card = Color(0xFF1C1C1E), cardAlt = Color(0xFF2C2C2E),
                text = Color(0xFFFFFFFF), sub = Color(0xFF8E8E93),
                accent = Color(0xFF0A84FF), onAccent = Color(0xFFFFFFFF),
                good = Color(0xFF30D158), warn = Color(0xFFFF9F0A), bad = Color(0xFFFF453A),
                divider = Color(0xFF38383A), radius = 24.dp, tileRadius = 22.dp, dark = true,
            )
        } else {
            Palette(
                bg = Color(0xFFF2F2F7), card = Color(0xFFFFFFFF), cardAlt = Color(0xFFE9E9EE),
                text = Color(0xFF000000), sub = Color(0xFF6C6C70),
                accent = Color(0xFF007AFF), onAccent = Color(0xFFFFFFFF),
                good = Color(0xFF34C759), warn = Color(0xFFFF9500), bad = Color(0xFFFF3B30),
                divider = Color(0xFFD1D1D6), radius = 24.dp, tileRadius = 22.dp, dark = false,
            )
        }
    DesignStyle.NINEBOT ->
        if (dark) {
            Palette(
                bg = Color(0xFF0E0F11), card = Color(0xFF1A1C20), cardAlt = Color(0xFF262A30),
                text = Color(0xFFF2F3F5), sub = Color(0xFF9AA0A8),
                accent = Color(0xFFFF6A13), onAccent = Color(0xFF111111),
                good = Color(0xFF3DDC84), warn = Color(0xFFFFB020), bad = Color(0xFFFF4D4D),
                divider = Color(0xFF2F333A), radius = 14.dp, tileRadius = 12.dp, dark = true,
            )
        } else {
            Palette(
                bg = Color(0xFFF1F2F4), card = Color(0xFFFFFFFF), cardAlt = Color(0xFFE4E6EA),
                text = Color(0xFF14161A), sub = Color(0xFF666C75),
                accent = Color(0xFFEF5F00), onAccent = Color(0xFFFFFFFF),
                good = Color(0xFF1FA463), warn = Color(0xFFE08A00), bad = Color(0xFFD93025),
                divider = Color(0xFFD5D8DD), radius = 14.dp, tileRadius = 12.dp, dark = false,
            )
        }
}

val LocalPalette = staticCompositionLocalOf { paletteFor(DesignStyle.APPLE, false) }

@Composable
fun EScooterTheme(mode: ThemeMode, style: DesignStyle, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val p = paletteFor(style, dark)
    val scheme = if (dark) {
        darkColorScheme(
            primary = p.accent, onPrimary = p.onAccent,
            background = p.bg, onBackground = p.text,
            surface = p.card, onSurface = p.text,
            surfaceVariant = p.cardAlt, onSurfaceVariant = p.sub,
        )
    } else {
        lightColorScheme(
            primary = p.accent, onPrimary = p.onAccent,
            background = p.bg, onBackground = p.text,
            surface = p.card, onSurface = p.text,
            surfaceVariant = p.cardAlt, onSurfaceVariant = p.sub,
        )
    }
    val view = LocalView.current
    SideEffect {
        val activity = view.context as? Activity
        if (activity != null) {
            val controller = WindowCompat.getInsetsController(activity.window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
