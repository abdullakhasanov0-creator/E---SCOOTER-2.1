package com.limonchik.escooter

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

/** Нажимаемая поверхность с быстрой пружинной анимацией нажатия. */
@Composable
fun Pressable(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    color: Color = LocalPalette.current.card,
    enabled: Boolean = true,
    content: @Composable BoxScope.() -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 900f),
        label = "press",
    )
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(color)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
        content = content,
    )
}

@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(p.radius))
            .background(p.card)
            .padding(16.dp),
    ) { content() }
}

@Composable
fun SectionTitle(text: String) {
    val p = LocalPalette.current
    Text(
        text,
        color = p.sub,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 6.dp, top = 18.dp, bottom = 8.dp),
    )
}

@Composable
fun BigTitle(text: String) {
    val p = LocalPalette.current
    Text(text, color = p.text, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp, top = 6.dp))
}

@Composable
fun InfoRow(label: String, value: String) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = p.sub, fontSize = 15.sp)
        Spacer(Modifier.width(12.dp))
        Text(value, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.End, modifier = Modifier.weight(1f, fill = false))
    }
}

@Composable
fun Divider1() {
    val p = LocalPalette.current
    Box(Modifier.fillMaxWidth().height(1.dp).background(p.divider))
}

/** Плитка в стиле карточки Apple Home: активная заливается акцентом. */
@Composable
fun Tile(
    glyph: String,
    title: String,
    subtitle: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val bg by animateColorAsState(if (active) p.accent else p.card, tween(180), label = "tileBg")
    val fg by animateColorAsState(if (active) p.onAccent else p.text, tween(180), label = "tileFg")
    val sub by animateColorAsState(if (active) p.onAccent else p.sub, tween(180), label = "tileSub")
    Pressable(
        onClick = onClick,
        modifier = modifier.height(112.dp),
        shape = RoundedCornerShape(p.tileRadius),
        color = bg,
        enabled = enabled,
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(if (active) Color(0x33FFFFFF) else p.cardAlt),
                contentAlignment = Alignment.Center,
            ) { Text(glyph, fontSize = 19.sp) }
            Column {
                Text(title, color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = sub, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (subtitle.isNotEmpty()) Text(subtitle, color = p.sub, fontSize = 13.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(checkedTrackColor = p.good, checkedThumbColor = Color.White, uncheckedTrackColor = p.cardAlt),
        )
    }
}

/** Сегментный переключатель в стиле iOS. */
@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(p.tileRadius)).background(p.cardAlt).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            val bg by animateColorAsState(if (on) p.card else Color.Transparent, tween(160), label = "seg")
            Pressable(
                onClick = { onSelect(i) },
                modifier = Modifier.weight(1f).height(38.dp),
                shape = RoundedCornerShape(p.tileRadius - 3.dp),
                color = bg,
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(label, color = if (on) p.accent else p.sub, fontSize = 14.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPalette.current
    Pressable(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(p.tileRadius),
        color = if (enabled) p.accent else p.cardAlt,
        enabled = enabled,
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text, color = if (enabled) p.onAccent else p.sub, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SecondaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPalette.current
    Pressable(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(p.tileRadius),
        color = p.cardAlt,
        enabled = enabled,
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text, color = if (enabled) p.accent else p.sub, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Спидометр: дуга 270 градусов, плавная пружинная анимация. */
@Composable
fun SpeedGauge(speed: Float, maxSpeed: Float, unit: String, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val frac by animateFloatAsState(
        targetValue = (speed / maxSpeed).coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "gauge",
    )
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(10.dp)) {
            val stroke = 20.dp.toPx()
            val inset = stroke / 2f
            val sz = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = p.cardAlt, startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = Offset(inset, inset), size = sz,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            if (frac > 0.002f) {
                drawArc(
                    color = p.accent, startAngle = 135f, sweepAngle = 270f * frac, useCenter = false,
                    topLeft = Offset(inset, inset), size = sz,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(String.format(Locale.US, "%.1f", speed), color = p.text, fontSize = 54.sp, fontWeight = FontWeight.Bold)
            Text(unit, color = p.sub, fontSize = 16.sp)
        }
    }
}

/** График скорости за сеанс. */
@Composable
fun SpeedChart(values: List<Float>, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Canvas(modifier.fillMaxWidth().height(110.dp)) {
        val top = (values.maxOrNull() ?: 0f).coerceAtLeast(10f)
        drawLine(p.divider, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = 2f)
        if (values.size >= 2) {
            val path = Path()
            val stepX = size.width / (values.size - 1).toFloat()
            values.forEachIndexed { i, v ->
                val x = stepX * i
                val y = size.height - (v / top) * (size.height - 6f) - 3f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, p.accent, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** Горизонтальная полоса заряда. */
@Composable
fun BatteryBar(percent: Int, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val frac by animateFloatAsState((percent / 100f).coerceIn(0f, 1f), tween(300), label = "bat")
    val color = if (percent <= 15) p.bad else if (percent <= 35) p.warn else p.good
    Box(modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(p.cardAlt)) {
        Box(Modifier.fillMaxWidth(frac).fillMaxSize().clip(RoundedCornerShape(7.dp)).background(color))
    }
}
